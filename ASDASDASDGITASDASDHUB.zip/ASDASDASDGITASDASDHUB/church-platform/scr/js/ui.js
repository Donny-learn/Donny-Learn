// This module handles all DOM interactions, rendering, and UI event listeners.


import { state, updateTheme } from './state.js';


// --- DOM Element References ---
const elements = {
    // Buttons
    mobileMenuButton: document.getElementById('mobile-menu-button'),
    themeToggleButton: document.getElementById('theme-toggle'), // Will add this button later
   
    // Dynamic Content Containers
    eventsCarousel: document.getElementById('events-carousel'),
    sermonArchiveGrid: document.getElementById('sermon-archive-grid'),
    eventsList: document.getElementById('events-list'),
   
    // Global UI elements
    loader: document.getElementById('loader'), // Will add this element later
    errorDisplay: document.getElementById('error-display') // Will add this element later
};


// --- Page Rendering Functions ---


/**
 * Renders the dynamic sections of the homepage.
 * @param {object} churchData - The data object containing sermons, events, etc.
 */
export function renderHomepage(churchData) {
    // We only need to render the events on the homepage for now.
    renderEventsCarousel(churchData.events);
}


/**
 * Renders the sermons page with a filterable archive.
 * @param {Array<object>} sermons - An array of sermon objects.
 */
export function renderSermonsPage(sermons) {
    if (!elements.sermonArchiveGrid) return;
    elements.sermonArchiveGrid.innerHTML = ''; // Clear mockups


    sermons.forEach(sermon => {
        const card = document.createElement('div');
        card.className = 'event-card'; // Reusing event-card style for now
       
        // Convert date string to a more readable format
        const sermonDate = new Date(sermon.date).toLocaleDateString('en-US', {
            year: 'numeric', month: 'long', day: 'numeric'
        });


        card.innerHTML = `
            <img src="https://placehold.co/600x400/3B82F6/FFFFFF?text=Sermon" alt="${sermon.title}" class="w-full h-48 object-cover">
            <div class="p-6">
                <p class="text-sm text-gray-500">${sermonDate}</p>
                <h3 class="font-bold font-display text-xl my-2">${sermon.title}</h3>
                <p class="text-gray-600 font-semibold mb-4">${sermon.speaker}</p>
            </div>
        `;
        elements.sermonArchiveGrid.appendChild(card);
    });
}


/**
 * Renders the events page with a filterable list.
 * @param {Array<object>} events - An array of event objects.
 */
export function renderEventsPage(events) {
    if (!elements.eventsList) return;
    elements.eventsList.innerHTML = ''; // Clear mockups


    events.forEach(event => {
        const item = document.createElement('div');
        item.className = 'event-list-item';
       
        const eventDate = new Date(event.date);
        const month = eventDate.toLocaleString('en-US', { month: 'short' }).toUpperCase();
        const day = eventDate.getDate();


        item.innerHTML = `
            <div class="event-date">
                <span class="month">${month}</span>
                <span class="day">${day}</span>
            </div>
            <div class="event-details">
                <h3 class="font-bold font-display text-xl">${event.title}</h3>
                <p class="text-gray-600">${eventDate.toLocaleDateString('en-US', { weekday: 'long' })} at ${eventDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })} | ${event.location}</p>
                <p class="mt-2 text-gray-700">${event.description}</p>
            </div>
            <a href="#" class="event-button">Details</a>
        `;
        elements.eventsList.appendChild(item);
    });
}




/**
 * Renders event cards into the homepage carousel.
 * @param {Array<object>} events - An array of event objects.
 */
function renderEventsCarousel(events) {
    if (!elements.eventsCarousel) return;
    elements.eventsCarousel.innerHTML = ''; // Clear placeholders


    // Get the next 3 upcoming events
    const upcomingEvents = events
        .filter(event => new Date(event.date) > new Date())
        .sort((a, b) => new Date(a.date) - new Date(b.date))
        .slice(0, 3);


    upcomingEvents.forEach(event => {
        const card = document.createElement('div');
        card.className = 'event-card';
       
        const eventDate = new Date(event.date);
        const dateString = eventDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
        const timeString = eventDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });


        card.innerHTML = `
            <img src="https://placehold.co/600x400/3B82F6/FFFFFF?text=Event" alt="${event.title}" class="w-full h-48 object-cover">
            <div class="p-6">
                <h3 class="font-bold font-display text-xl mb-2">${event.title}</h3>
                <p class="text-gray-600 font-semibold mb-4">${dateString} | ${timeString}</p>
                <p class="text-gray-700">${event.description}</p>
            </div>
        `;
        elements.eventsCarousel.appendChild(card);
    });
}




// --- UI Event Listeners & Setup ---


/**
 * Sets up all the global event listeners for the site.
 */
export function setupEventListeners() {
    if (elements.mobileMenuButton) {
        elements.mobileMenuButton.addEventListener('click', () => {
            alert("Mobile menu would open here!");
        });
    }


    if (elements.themeToggleButton) {
        elements.themeToggleButton.addEventListener('click', () => {
            const newTheme = state.theme === 'light' ? 'dark' : 'light';
            updateTheme(newTheme);
            applyTheme();
        });
    }
}


/**
 * Applies the current theme to the body.
 */
export function applyTheme() {
    // This function will be expanded later to add/remove a 'dark' class
    console.log(`Applying ${state.theme} theme.`);
}


// --- Utility Functions ---


export function showLoader() {
    // Logic to show a loading spinner
    console.log("Showing loader...");
}


export function hideLoader() {
    // Logic to hide the loading spinner
    console.log("Hiding loader...");
}


export function displayError(message) {
    // Logic to display an error message to the user
    console.error("Displaying error:", message);
    alert(`Error: ${message}`);
}





