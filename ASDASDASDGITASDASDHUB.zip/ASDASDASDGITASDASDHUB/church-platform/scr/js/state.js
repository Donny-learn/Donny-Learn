// This module holds and manages the global state for the application.


export const state = {
    // Load the theme from localStorage, defaulting to 'light' if not set
    theme: localStorage.getItem('theme') || 'light',
};


/**
 * Updates the theme in the state and saves it to localStorage.
 * @param {string} newTheme - The new theme to set ('light' or 'dark').
 */
export function updateTheme(newTheme) {
    state.theme = newTheme;
    localStorage.setItem('theme', newTheme);
}





