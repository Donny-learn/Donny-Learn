// This is the main entry point for the application.
// It orchestrates the other modules.


import { state, updateTheme } from './state.js';
import { fetchAllDataForChurch } from './api.js';
import {
    renderHomepage,
    renderSermonsPage,
    renderEventsPage,
    // ... other page renderers will be imported here
    setupEventListeners,
    applyTheme,
    showLoader,
    hideLoader,
    displayError
} from './ui.js';


/**
 * Initializes the application on page load.
 */
async function init() {
    // Apply the user's saved theme preference first
    applyTheme();
   
    // Setup all global event listeners (like for the mobile menu, etc.)
    setupEventListeners();


    // Determine which church's content to load based on the subdomain
    // For now, we will hardcode it. This will be made dynamic later.
    const churchId = 'missionary-baptist-church';


    showLoader(); // Show a loading indicator


    try {
        // Fetch all the necessary data for this church from Firebase
        const churchData = await fetchAllDataForChurch(churchId);
       
        // Pass the fetched data to the appropriate function to render the current page
        route(churchData);


    } catch (error) {
        console.error("Failed to initialize the application:", error);
        displayError("Could not load church data. Please try again later.");
    } finally {
        hideLoader(); // Hide the loading indicator
    }
}


/**
 * A simple router to determine which page to render based on the URL.
 * @param {object} churchData - The data object containing sermons, events, etc.
 */
function route(churchData) {
    const path = window.location.pathname;


    if (path.endsWith('/') || path.endsWith('index.html')) {
        renderHomepage(churchData);
    } else if (path.endsWith('sermons.html')) {
        renderSermonsPage(churchData.sermons);
    } else if (path.endsWith('events.html')) {
        renderEventsPage(churchData.events);
    }
    // ... other routes for other pages will be added here
}




// Start the application
init();



